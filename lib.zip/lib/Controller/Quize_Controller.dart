import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project15/Model/Question_Model.dart';

class Quize_Controller extends GetxController {
  String name = '';
  List<Question_Model> _questions = [
    Question_Model(
        id: 1,
        question: "What is the capital of Syria?",
        options: ["Damascus", "Beruit", "Arpil"],
        answer: 1),
    Question_Model(
        id: 2,
        question: "What is the most famouse language in the world?",
        options: ["Spanish", "English", "Frensh"],
        answer: 2),
    Question_Model(
        id: 3,
        question: "Who is the best player in the world?",
        options: ["Pele", "Messi", "Ronlado"],
        answer: 3),
    Question_Model(
        id: 4,
        question: "What is the nationality of Albert Einstein?",
        options: ["German", "American", "Spanish"],
        answer: 1),
  ];

  bool _isPressed = false;
  double _numberOfQuestoin = 1;
  int? _selectedAnswer;
  int _countOfCorrectedAnswer = 1;
  final RxInt _sec = 15.obs;

  int get countOfQuestion => _questions.length;
  List<Question_Model> get questions => [..._questions]; //???
  bool get isPressed => _isPressed;
  double get numberOfQuestoin => _numberOfQuestoin;
  int? get selectedAnswer => _selectedAnswer;
  int get countOfCorrectedAnswer => _countOfCorrectedAnswer;
  RxInt get sec => _sec;
  int? _correctAnswer;
  final Map<int, bool> __questionIsAnswerd = {};
  Timer? _timer;
  final maxSec = 15;
  late PageController pageController; //???

  @override
  void onInit() {
    pageController = PageController(initialPage: 0);
    restAnswer();
    super.onInit();
  }

  @override
  void onClose() {
    pageController.dispose();
    super.onClose();
  }

  double get socreResult {
    //??
    return countOfCorrectedAnswer * 100 / _questions.length;
  }

  void checkAnswer(Question_Model question_model, int selectedAnswer) {
    _isPressed = true;
    _selectedAnswer = selectedAnswer;
    _correctAnswer = question_model.answer;
    if (_correctAnswer == _selectedAnswer) {
      _countOfCorrectedAnswer++;
    }
    stopTimer();

    __questionIsAnswerd.update(question_model.id, (value) => true);
    Future.delayed(const Duration(microseconds: 500))
        .then((value) => nextQuestion());
  }

  bool checkIfQuestionIsAnswred(int questionId) {
    return __questionIsAnswerd.entries
        .firstWhere((element) => element.key == questionId)
        .value;
  }

  void restAnswer() {
    
    for(var element in _questions){
      __questionIsAnswerd.addAll({element.id:false});
    }

    update();

  }

  Color getColor(int answerIndex){
    if(isPressed){
      if(answerIndex == _correctAnswer){
        return Colors.green;
      }
      else if(answerIndex == _selectedAnswer && _correctAnswer!=_selectedAnswer){
        return Colors.red;
      }
    }
    return Colors.white;
  }

    IconData getIcon(int answerIndex){
    if(isPressed){
      if(answerIndex == _correctAnswer){
        return Icons.done;
      }
      else if(answerIndex == _selectedAnswer && _correctAnswer!=_selectedAnswer){
        return Icons.close;
      }
    }
    return Icons.close;
  }


  nextQuestion() {
    if(_timer!=null || _timer!.isActive){
      stopTimer();
    }

    if(pageController.page == _questions.length-1){
      //navigate to the result screen 
    }

    else {
      _isPressed = false;
      pageController.nextPage(duration: const Duration(microseconds: 500), curve: Curves.linear);
      startTimer();
    }
    
    _numberOfQuestoin=pageController.page!+2;
    update();


  }
  
  void startTimer() {
    restTimer();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if(_sec.value>0){
        _sec.value--;
      }
      else{
        stopTimer();
        nextQuestion();
      }
     });
  }
  
  void stopTimer() => _timer!.cancel();
  void restTimer() => _sec.value = maxSec;
  void startAgain(){
    _correctAnswer = null;
    _countOfCorrectedAnswer = 0;
    _selectedAnswer = null;
    restAnswer();
  }
}
