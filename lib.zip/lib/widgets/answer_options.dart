import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:project15/Controller/Quize_Controller.dart';

// ignore: must_be_immutable
class AnswerOptions extends StatelessWidget {
  String text;
  int index, questionId;
  Function() onPressed;

  AnswerOptions(
      {required this.text,
      required this.index,
      required this.questionId,
      required this.onPressed}
      );

  @override
  Widget build(BuildContext context) {
    return GetBuilder<Quize_Controller>(
        init: Quize_Controller(),
        builder: (controller) => InkWell(
              onTap: controller.checkIfQuestionIsAnswred(questionId)
                  ? null
                  : onPressed,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                        width: 3, color: controller.getColor(index))),
                child: Padding(
                  padding: EdgeInsets.all(15.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      RichText(text: TextSpan(
                        text: '${index + 1}',
                        style: Theme.of(context).textTheme.headlineLarge,
                        children: [
                          TextSpan(
                            text: text,
                            style: Theme.of(context).textTheme.headlineLarge,
                          )
                        ]
                      )),
                      if (controller.checkIfQuestionIsAnswred(questionId) && controller.selectedAnswer == index)
                      Container(
                        width:  30,
                        height: 30,
                        padding: EdgeInsets.zero,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color:controller.getColor(index),
                          border: Border.all(
                            color: Colors.white,
                          )
                        ),
                      )
                    ],
                  ),
                  ),
              ),
            ));
  }
}
