class Question_Model {
  int id, answer;
  String question;
  List<String> options;

  Question_Model(
      {required this.id,
      required this.question,
      required this.options,
      required this.answer});
}
