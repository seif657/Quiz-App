import 'package:flutter/material.dart';

const kPrimaryColor = Colors.amber;
const kSecColor = Colors.amber;
